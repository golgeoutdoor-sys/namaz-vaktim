# Namaz Vaktim

Android namaz vakitleri ve günlük ayet uygulaması.

## Özellikler
- AlAdhan API Method 13 ile namaz vakitleri
- GPS konumu veya manuel şehir seçimi
- Namazdan 3 dakika önce yerel bildirim
- Her gün 09:00 Günün Ayeti bildirimi
- 365 günlük offline ayet arşivi
- Arapça + Elmalılı Türkçe meal
- Ayet paylaşımı

## APK
GitHub Actions otomatik olarak debug APK üretir.
Actions > Build Namaz Vaktim APK > Run workflow.

## Veri
365 günlük ayet arşivi uygulamaya offline olarak gömülüdür. Ticari Google Play yayını öncesinde meal lisansı/atıf koşulları ve veri kaynağı şartları ayrıca doğrulanmalıdır.
