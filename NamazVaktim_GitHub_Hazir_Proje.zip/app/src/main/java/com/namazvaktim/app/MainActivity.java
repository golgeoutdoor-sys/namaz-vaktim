package com.namazvaktim.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    LinearLayout root, prayerBox;
    TextView locationText, dateText, ayetArabic, ayetTurkish, ayetRef, categoryText;
    EditText cityInput;
    final ExecutorService executor = Executors.newSingleThreadExecutor();
    SharedPreferences prefs;
    JSONObject timings;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String text, float size, int color){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t;
    }
    Button btn(String text){ Button b=new Button(this); b.setText(text); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("namaz",MODE_PRIVATE);
        buildUi();
        NotificationHelper.createChannels(this);
        requestNotificationPermission();
        showAyet();
        String saved=prefs.getString("city","");
        if(!saved.isEmpty()) locationText.setText("Konum: "+saved);
        fetchPrayerTimesFromSavedOrLocation();
    }

    void buildUi(){
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(12),dp(16),dp(24));
        scroll.addView(root); setContentView(scroll);

        TextView title=tv("🕌 Namaz Vaktim",28,Color.rgb(27,94,32));
        title.setGravity(Gravity.CENTER); root.addView(title);
        dateText=tv("",15,Color.DKGRAY); dateText.setGravity(Gravity.CENTER); root.addView(dateText);

        locationText=tv("Konum: belirleniyor...",16,Color.DKGRAY); root.addView(locationText);
        Button loc=btn("📍 Konumumu Kullan");
        loc.setOnClickListener(v->requestLocation());
        root.addView(loc);

        cityInput=new EditText(this); cityInput.setHint("Şehir/ilçe yazın (örn. İzmir)");
        root.addView(cityInput);
        Button city=btn("Şehri Kullan");
        city.setOnClickListener(v->useCity());
        root.addView(city);

        TextView h=tv("Bugünün Namaz Vakitleri",21,Color.rgb(27,94,32)); root.addView(h);
        prayerBox=new LinearLayout(this); prayerBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(prayerBox);

        TextView ah=tv("📖 Günün Ayeti",23,Color.rgb(27,94,32)); root.addView(ah);
        categoryText=tv("",14,Color.GRAY); root.addView(categoryText);
        ayetArabic=tv("",23,Color.DKGRAY); ayetArabic.setGravity(Gravity.RIGHT); ayetArabic.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(ayetArabic);
        ayetTurkish=tv("",17,Color.DKGRAY); root.addView(ayetTurkish);
        ayetRef=tv("",14,Color.GRAY); root.addView(ayetRef);
        Button share=btn("📤 Ayeti Paylaş");
        share.setOnClickListener(v->shareAyet());
        root.addView(share);

        Button settings=btn("⚙️ Bildirim Ayarları");
        settings.setOnClickListener(v->{
            if(Build.VERSION.SDK_INT>=31 && !getSystemService(AlarmManager.class).canScheduleExactAlarms()){
                try{ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); }catch(Exception e){}
            } else Toast.makeText(this,"Namaz bildirimleri 3 dakika önce planlanır. Android bildirim izni açık olmalıdır.",Toast.LENGTH_LONG).show();
        });
        root.addView(settings);

        TextView license=tv("Lisanslar: Arapça metin ve Elmalılı meal, uygulamaya sağlanan veri dosyasından alınmıştır. Ticari yayın öncesi ilgili lisans/atıf koşulları doğrulanmalıdır.",12,Color.GRAY);
        root.addView(license);
    }

    void showAyet(){
        try{
            InputStream is=getAssets().open("365_ayet.json");
            String s=new String(readAll(is),"UTF-8"); JSONObject o=new JSONObject(s);
            JSONArray a=o.getJSONArray("items");
            Calendar c=Calendar.getInstance(); int d=c.get(Calendar.DAY_OF_YEAR); if(d>365)d=365;
            JSONObject x=a.getJSONObject(d-1);
            categoryText.setText("Kategori: "+x.optString("category",""));
            ayetArabic.setText(x.optString("arabic",""));
            ayetTurkish.setText(x.optString("turkish_meaning",""));
            ayetRef.setText(x.optString("surah","")+" Suresi • "+x.optInt("ayah")+". Ayet");
            dateText.setText(new SimpleDateFormat("dd MMMM yyyy",new Locale("tr","TR")).format(c.getTime()));
        }catch(Exception e){ ayetTurkish.setText("Ayet yüklenemedi."); }
    }

    void shareAyet(){
        String text=ayetArabic.getText()+"\n\n"+ayetTurkish.getText()+"\n\n"+ayetRef.getText()+"\n\nNamaz Vaktim";
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text);
        startActivity(Intent.createChooser(i,"Ayet paylaş"));
    }

    void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);
    }

    void requestLocation(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},20); return;
        }
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        Location last=null;
        try{
            last=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(last==null) last=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }catch(Exception e){}
        if(last!=null) loadPrayer(last.getLatitude(),last.getLongitude(),"Konum");
        else Toast.makeText(this,"Konum alınamadı. Şehir seçimini kullanabilirsiniz.",Toast.LENGTH_LONG).show();
    }

    void fetchPrayerTimesFromSavedOrLocation(){
        if(!prefs.getString("city","").isEmpty()){
            double lat=prefs.getFloat("lat",0), lon=prefs.getFloat("lon",0);
            if(lat!=0 || lon!=0) loadPrayer(lat,lon,prefs.getString("city",""));
            else requestLocation();
        } else requestLocation();
    }

    void useCity(){
        String city=cityInput.getText().toString().trim();
        if(city.isEmpty()) return;
        executor.execute(()->{
            try{
                Geocoder g=new Geocoder(this,new Locale("tr","TR"));
                List<Address> a=g.getFromLocationName(city,1);
                if(a==null||a.isEmpty()){runOnUiThread(()->Toast.makeText(this,"Şehir bulunamadı.",Toast.LENGTH_SHORT).show());return;}
                Address x=a.get(0);
                prefs.edit().putString("city",city).putFloat("lat",(float)x.getLatitude()).putFloat("lon",(float)x.getLongitude()).apply();
                loadPrayer(x.getLatitude(),x.getLongitude(),city);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Şehir aranırken hata oluştu.",Toast.LENGTH_SHORT).show());}
        });
    }

    void loadPrayer(double lat,double lon,String label){
        executor.execute(()->{
            try{
                String date=new SimpleDateFormat("dd-MM-yyyy",Locale.US).format(new Date());
                URL u=new URL("https://api.aladhan.com/v1/timings/"+date+"?latitude="+lat+"&longitude="+lon+"&method=13");
                HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000);
                String s=new String(readAll(c.getInputStream()),"UTF-8"); JSONObject data=new JSONObject(s).getJSONObject("data");
                JSONObject t=data.getJSONObject("timings"); timings=t;
                String[] names={"Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"};
                String[] tr={"İmsak","Güneş","Öğle","İkindi","Akşam","Yatsı"};
                runOnUiThread(()->{
                    locationText.setText("Konum: "+label);
                    prayerBox.removeAllViews();
                    for(int i=0;i<names.length;i++) prayerBox.addView(tv(tr[i]+"  —  "+t.optString(names[i]),18,Color.DKGRAY));
                    NotificationHelper.schedulePrayerNotifications(this,t);
                    NotificationHelper.scheduleDailyAyet(this);
                });
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Namaz vakitleri alınamadı. İnternet bağlantınızı kontrol edin.",Toast.LENGTH_LONG).show());}
        });
    }


    static byte[] readAll(InputStream is)throws IOException{
        ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
        while((n=is.read(buf))!=-1)b.write(buf,0,n); return b.toByteArray();
    }

    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
