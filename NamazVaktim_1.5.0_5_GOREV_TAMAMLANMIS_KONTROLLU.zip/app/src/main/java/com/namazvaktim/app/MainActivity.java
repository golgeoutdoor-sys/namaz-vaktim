package com.namazvaktim.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.location.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    LinearLayout root, prayerBox;
    TextView locationText, dateText, countdownText, ayetArabic, ayetTurkish, ayetRef, categoryText;
    EditText cityInput;
    SharedPreferences prefs;
    JSONObject timings;
    final ExecutorService executor=Executors.newSingleThreadExecutor();
    final Handler handler=new Handler(Looper.getMainLooper());
    String currentScreen="main";
    int lastQuranPage=1;
    SensorManager sensorManager;
    Sensor rotationSensor;
    float deviceAzimuth=0f;
    float qiblaBearing=0f;
    QiblaCompassView qiblaView;

    static final String PREF_DONE="onboarding_done";
    static final String PREF_THEME="theme";
    static final String PREF_NOTIFY_MIN="notify_min";
    static final String PREF_NOTIFY_ON="notify_on";
    static final String PREF_AYET_NOTIFY="ayet_notify";
    static final String PREF_QURAN_PAGE="quran_page";

    final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateCountdown();
            handler.postDelayed(this,1000);
        }
    };

    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    boolean night(){ return "night".equals(prefs.getString(PREF_THEME,"green")); }
    int bg(){return night()?Color.rgb(7,25,48):Color.rgb(250,248,242);} 
    int surface(){return night()?Color.rgb(13,42,72):Color.rgb(255,253,247);} 
    int primary(){return night()?Color.rgb(105,220,113):Color.rgb(27,94,32);} 
    int text(){return night()?Color.rgb(245,248,250):Color.rgb(45,45,45);} 
    int secondary(){return night()?Color.rgb(190,202,214):Color.rgb(95,95,95);} 
    int accent(){return night()?Color.rgb(255,193,7):Color.rgb(46,125,50);} 

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("namaz",MODE_PRIVATE);
        applyBars();
        NotificationHelper.createChannels(this);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        if(sensorManager!=null) rotationSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        requestNotificationPermission();
        if(prefs.getBoolean(PREF_DONE,false)) showMainScreen(); else showFirstLaunch();
    }
    void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT >= 33 &&
           checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);
        }
    }
    void applyBars(){
        getWindow().setStatusBarColor(night()?Color.rgb(4,20,38):Color.rgb(27,94,32));
        getWindow().setNavigationBarColor(night()?Color.rgb(4,20,38):bg());
        int flags=getWindow().getDecorView().getSystemUiVisibility();
        if(!night()) flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; else flags&=~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }
    TextView tv(String s,float size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setPadding(dp(8),dp(7),dp(8),dp(7));return t;}
    Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(15); b.setTextColor(text());
        b.setMinHeight(dp(48)); b.setPadding(dp(14),dp(8),dp(14),dp(8));
        GradientDrawable gd=new GradientDrawable();
        gd.setColor(surface()); gd.setCornerRadius(cardRadius()); gd.setStroke(dp(1),border());
        b.setBackground(gd); b.setElevation(dp(2));
        return b;
    }
    EditText themedEdit(String hint){
        EditText e=new EditText(this);
        e.setHint(hint); e.setHintTextColor(secondary()); e.setTextColor(text());
        e.setSingleLine(true); e.setPadding(dp(12),dp(4),dp(12),dp(4));
        GradientDrawable gd=new GradientDrawable(); gd.setColor(surface()); gd.setCornerRadius(cardRadius()); gd.setStroke(dp(1),border());
        e.setBackground(gd); return e;
    }
    void themeView(View v){
        if(v instanceof TextView) ((TextView)v).setTextColor(text());
        if(v instanceof EditText){((EditText)v).setTextColor(text());((EditText)v).setHintTextColor(secondary());}
        if(v instanceof Button){((Button)v).setTextColor(text());}
        if(v instanceof CheckBox)((CheckBox)v).setTextColor(text());
    }
    LinearLayout page(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(16),dp(10),dp(16),dp(24));p.setBackgroundColor(bg());return p;}
    TextView title(String s){TextView t=tv(s,26,primary());t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER);return t;}
    void base(LinearLayout p,String name){
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(0,dp(4),0,dp(4));
        Button back=btn("‹");back.setTextSize(32);back.setPadding(0,0,0,0);back.setOnClickListener(v->showMainScreen());
        bar.addView(back,new LinearLayout.LayoutParams(dp(50),dp(55)));
        TextView t=title(name);bar.addView(t,new LinearLayout.LayoutParams(0,dp(55),1));
        p.addView(bar);
    }
    void setPage(LinearLayout p,String screen){
        currentScreen=screen;
        ScrollView s=new ScrollView(this);
        s.setBackgroundColor(bg());
        s.addView(p);
        setContentView(s);
        applyBars();
    }

    void showFirstLaunch(){
        LinearLayout p=page();p.setGravity(Gravity.CENTER_HORIZONTAL);p.setPadding(dp(20),dp(36),dp(20),dp(30));
        TextView h=title("🕌 Namaz Vaktim");p.addView(h,new LinearLayout.LayoutParams(-1,dp(65)));
        TextView w=tv("Hoş geldiniz",23,text());w.setGravity(Gravity.CENTER);p.addView(w);
        TextView info=tv("İlk açılışta konumunuzu veya şehrinizi seçin. Seçiminiz kaydedilir ve sonraki açılışlarda bu sayfa tekrar gösterilmez.",16,text());info.setGravity(Gravity.CENTER);p.addView(info);
        Button loc=btn("📍 KONUMUMU KULLAN");loc.setOnClickListener(v->requestLocation(true));p.addView(loc,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView or=tv("veya",14,secondary());or.setGravity(Gravity.CENTER);p.addView(or);
        cityInput=themedEdit("Şehir / ilçe (örn. Manisa)");p.addView(cityInput,new LinearLayout.LayoutParams(-1,dp(55)));
        Button city=btn("🏙️ ŞEHRİ KULLAN");city.setOnClickListener(v->useCityFromOnboarding());p.addView(city,new LinearLayout.LayoutParams(-1,dp(56)));
        setPage(p,"onboarding");
    }

    void showMainScreen(){
        LinearLayout p=page();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=title("🕌 Namaz Vaktim");top.addView(h,new LinearLayout.LayoutParams(0,dp(58),1));
        Button menu=btn("☰");menu.setTextSize(25);menu.setOnClickListener(v->showMenu());top.addView(menu,new LinearLayout.LayoutParams(dp(58),dp(58)));p.addView(top);
        dateText=tv("",15,text());dateText.setGravity(Gravity.CENTER);p.addView(dateText);
        locationText=tv("Konum: yükleniyor...",16,text());p.addView(locationText);
        FrameLayout compassFrame=new FrameLayout(this);
        compassFrame.setPadding(0,dp(4),0,dp(4));
        qiblaView=new QiblaCompassView(this);
        qiblaView.setContentDescription("Kıble pusulası");
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(112),dp(112),Gravity.RIGHT|Gravity.TOP);
        compassFrame.addView(qiblaView,cp);
        TextView compassHint=tv("KIBLE",11,primary());compassHint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(112),dp(24),Gravity.RIGHT|Gravity.BOTTOM);
        compassFrame.addView(compassHint,hp);
        p.addView(compassFrame,new LinearLayout.LayoutParams(-1,dp(124)));
        countdownText=tv("⏳ Bir sonraki namaz hesaplanıyor...",20,primary());countdownText.setGravity(Gravity.CENTER);p.addView(card(countdownText));
        TextView ph=tv("Bugünün Namaz Vakitleri",22,primary());ph.setTypeface(Typeface.DEFAULT,Typeface.BOLD);p.addView(ph);
        prayerBox=new LinearLayout(this);prayerBox.setOrientation(LinearLayout.VERTICAL);p.addView(card(prayerBox));
        TextView kh=tv("⏰ Kerahat Vakitleri",20,primary());kh.setTypeface(Typeface.DEFAULT,Typeface.BOLD);p.addView(kh);
        LinearLayout kbox=new LinearLayout(this);kbox.setOrientation(LinearLayout.VERTICAL);p.addView(card(kbox));
        fillKerahetBox(kbox);
        TextView ah=tv("📖 Günün Ayeti",22,primary());ah.setTypeface(Typeface.DEFAULT,Typeface.BOLD);p.addView(ah);
        LinearLayout ab=new LinearLayout(this);ab.setOrientation(LinearLayout.VERTICAL);
        categoryText=tv("",14,secondary());ab.addView(categoryText);ayetArabic=tv("",23,text());ayetArabic.setGravity(Gravity.RIGHT);ayetArabic.setTextDirection(View.TEXT_DIRECTION_RTL);ab.addView(ayetArabic);ayetTurkish=tv("",17,text());ab.addView(ayetTurkish);ayetRef=tv("",14,secondary());ab.addView(ayetRef);
        Button share=btn("📤 Ayeti Paylaş");share.setOnClickListener(v->shareAyet());ab.addView(share);p.addView(card(ab));
        showAyet();
        String city=prefs.getString("city","");if(!city.isEmpty())locationText.setText("Konum: "+city);
        double lat=prefs.getFloat("lat",0),lon=prefs.getFloat("lon",0);if(lat!=0||lon!=0){setQiblaBearing(lat,lon);loadPrayer(lat,lon,city);}
        setPage(p,"main");handler.removeCallbacks(ticker);handler.post(ticker);
    }
    View card(View v){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10),dp(10),dp(10),dp(10));
        GradientDrawable gd=new GradientDrawable(); gd.setColor(surface()); gd.setCornerRadius(cardRadius()); gd.setStroke(dp(1),border());
        box.setBackground(gd); box.setElevation(dp(2)); box.addView(v);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(8));box.setLayoutParams(lp);
        return box;
    }

    void styleDialog(AlertDialog d){
        try{
            Window w=d.getWindow();
            if(w!=null){
                w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(bg()));
                TextView title=d.findViewById(android.R.id.alertTitle);
                if(title!=null){title.setTextColor(primary());title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);}
                ListView list=d.getListView();
                if(list!=null){
                    list.setBackgroundColor(bg());
                    for(int i=0;i<list.getChildCount();i++)themeView(list.getChildAt(i));
                }
                Button pos=d.getButton(AlertDialog.BUTTON_POSITIVE);
                Button neg=d.getButton(AlertDialog.BUTTON_NEGATIVE);
                Button neu=d.getButton(AlertDialog.BUTTON_NEUTRAL);
                if(pos!=null)pos.setTextColor(primary());
                if(neg!=null)neg.setTextColor(primary());
                if(neu!=null)neu.setTextColor(primary());
            }
        }catch(Exception ignored){}
    }

    void showMenu(){
        final String[] items={"🕌 Namaz Vakitleri","📿 Nasıl Kılınır?","📖 Ayetler","🤲 Dualar","⚙️ Ayarlar"};
        AlertDialog d=new AlertDialog.Builder(this).setTitle("☰ Menü").setItems(items,(dialog,w)->{
            if(w==0)showPrayerScreen(); else if(w==1)showHowTo(); else if(w==2)showAyetler(); else if(w==3)showDualar(); else showSettings();
        }).create();
        d.setOnShowListener(x->styleDialog(d)); d.show();
    }

    void showPrayerScreen(){LinearLayout p=page();base(p,"Namaz Vakitleri");TextView c=tv("",20,primary());c.setGravity(Gravity.CENTER);p.addView(card(c));
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);p.addView(card(b));
        String city=prefs.getString("city","Konumum");TextView l=tv("📍 "+city,18,text());b.addView(l);String[] n={"Sabah","Güneş","Öğle","İkindi","Akşam","Yatsı"};String[] k={"Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"};
        if(timings!=null)for(int i=0;i<n.length;i++)b.addView(tv(n[i]+" — "+timings.optString(k[i],"--:--"),18,text()));
        LinearLayout kb=new LinearLayout(this);kb.setOrientation(LinearLayout.VERTICAL);p.addView(card(kb));fillKerahetBox(kb);setPage(p,"prayer");
    }

    void showHowTo(){LinearLayout p=page();base(p,"Nasıl Kılınır?");String[] names={"Abdest nasıl alınır?","Sabah Namazı","Öğle Namazı","İkindi Namazı","Akşam Namazı","Yatsı Namazı"};for(String n:names){Button b=btn(n);b.setOnClickListener(v->showHowDetail(n));p.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));}setPage(p,"how");}
    void showHowDetail(String name){LinearLayout p=page();base(p,name);TextView t=tv(howText(name),16,text());t.setLineSpacing(0,1.12f);p.addView(card(t));setPage(p,"howdetail");}
    String howText(String n){
        if(n.startsWith("Abdest")) return "ABDEST NASIL ALINIR?\n\n1. Niyet: Abdest almaya niyet edilir.\n2. Besmele: Besmele çekilir.\n3. Eller: Eller bileklere kadar yıkanır. Parmak araları temizlenir.\n4. Ağız ve burun: Ağız üç kez çalkalanır, buruna su verilip temizlenir.\n5. Yüz: Alın saç bitiminden çene altına ve iki kulak arasına kadar yıkanır.\n6. Kollar: Önce sağ, sonra sol kol dirsekle birlikte yıkanır.\n7. Baş ve kulaklar: Baş mesh edilir; kulaklar ve ense mesh edilir.\n8. Ayaklar: Önce sağ, sonra sol ayak topuklarla birlikte yıkanır; parmak araları temizlenir.\n\nAbdestin farzları ve bazı ayrıntılar mezheplere göre farklı değerlendirilebilir. Bu bölüm temel öğrenme rehberidir.";
        if(n.equals("Sabah Namazı")) return "SABAH NAMAZI\n\nToplam: 2 rekât sünnet + 2 rekât farz.\n\nSünnet: Niyet edilir, tekbir alınır. Kıyamda Sübhaneke, Eûzü-Besmele ve Fâtiha ile bir sûre okunur. Rükû ve iki secdeden sonra ikinci rekâta kalkılır. İkinci rekâtın sonunda oturulup Ettehiyyâtü, Salli-Barik ve Rabbena duaları okunur, sağa ve sola selam verilir.\n\nFarz: 2 rekât olarak kılınır. İkinci rekâtın sonunda son oturuş yapılır ve selam verilir.\n\nNot: Kıraat ve duaların ayrıntıları mezheplere göre değişebilir.";
        if(n.equals("Öğle Namazı")) return "ÖĞLE NAMAZI\n\nToplam: 4 rekât ilk sünnet + 4 rekât farz + 2 rekât son sünnet.\n\nİlk sünnet: Dört rekât kılınır. İkinci rekâtta ilk oturuş yapılır; üçüncü rekâta kalkınca kıraate yeniden başlanır. Dördüncü rekât sonunda son oturuş ve selam yapılır.\n\nFarz: Dört rekâttır. İkinci rekât sonunda ilk oturuş, dördüncü rekât sonunda son oturuş ve selam yapılır.\n\nSon sünnet: Sabah sünneti gibi 2 rekât kılınır.";
        if(n.equals("İkindi Namazı")) return "İKİNDİ NAMAZI\n\nToplam: 4 rekât sünnet + 4 rekât farz.\n\nSünnet: Dört rekât olarak kılınır. İkinci rekâtta oturuş yapılır; dördüncü rekât sonunda son oturuş ve selam verilir.\n\nFarz: Dört rekât olarak kılınır. İkinci rekâtta ilk oturuş, dördüncü rekâtta son oturuş yapılır.\n\nNot: Sünnetin ayrıntıları mezheplere göre farklılık gösterebilir.";
        if(n.equals("Akşam Namazı")) return "AKŞAM NAMAZI\n\nToplam: 3 rekât farz + 2 rekât son sünnet.\n\nFarz: Üç rekâttır. İkinci rekât sonunda ilk oturuş yapılır. Üçüncü rekâtta kıyamdan sonra rükû ve secdeler yapılır; son oturuşta dualar okunur ve selam verilir.\n\nSon sünnet: 2 rekât olarak kılınır. İkinci rekât sonunda son oturuş ve selam yapılır.";
        return "YATSI NAMAZI\n\nToplam: 4 rekât ilk sünnet + 4 rekât farz + 2 rekât son sünnet + 3 rekât vitir.\n\nİlk sünnet: 4 rekât. Farz: 4 rekât. Son sünnet: 2 rekât.\n\nVitir: 3 rekâttır. Hanefî uygulamasında üçüncü rekâtta Kunut dualarıyla ilgili özel uygulama bulunur. Diğer mezheplerde vitrin hükmü ve kılınışı farklı olabilir.\n\nBu bölüm temel öğrenme rehberidir; ibadetlerin ayrıntılı uygulamasında güvenilir bir ilmihal veya din görevlisinden destek alınması uygundur.";
    }

    void showAyetler(){LinearLayout p=page();base(p,"Ayetler");Button read=btn("📖 Kur'an'ı Oku — 604 Sayfa");read.setOnClickListener(v->showQuranReader(prefs.getInt(PREF_QURAN_PAGE,1)));p.addView(read);Button find=btn("🔎 Sure / Ayet Bul");find.setOnClickListener(v->showAyetFinder());p.addView(find);Button day=btn("🌟 Günün Ayeti");day.setOnClickListener(v->showDailyAyetDetail());p.addView(day);TextView info=tv("Kur'an okuyucuda sayfa numarası, yakınlaştırma, son sayfaya devam ve ayeti Mushaf'ta açma özellikleri bulunur.",14,secondary());p.addView(info);setPage(p,"ayetler");}

    void showDailyAyetDetail(){
        LinearLayout p=page();base(p,"Günün Ayeti");
        try{
            JSONObject o=new JSONObject(new String(readAll(getAssets().open("365_ayet.json")),"UTF-8"));
            JSONArray a=o.getJSONArray("items"); int d=Calendar.getInstance().get(Calendar.DAY_OF_YEAR); if(d>365)d=365;
            JSONObject x=a.getJSONObject(d-1);
            p.addView(card(tv("Kategori: "+x.optString("category"),14,secondary())));
            TextView ar=tv(x.optString("arabic"),26,text()); ar.setGravity(Gravity.RIGHT); ar.setTextDirection(View.TEXT_DIRECTION_RTL); p.addView(card(ar));
            p.addView(card(tv(x.optString("turkish_meaning"),17,text())));
            p.addView(tv(x.optString("surah")+" Suresi • "+x.optInt("ayah")+". Ayet",14,secondary()));
            Button share=btn("📤 Görselli Paylaş"); share.setOnClickListener(v->shareAyetCard(x.optString("arabic"),x.optString("turkish_meaning"),x.optString("surah")+" Suresi • "+x.optInt("ayah")+". Ayet")); p.addView(share);
        }catch(Exception e){p.addView(tv("Günün ayeti yüklenemedi.",16,text()));}
        setPage(p,"daily");
    }

    void showAyetFinder(){LinearLayout p=page();base(p,"Sure / Ayet Bul");TextView info=tv("Örnek: Bakara 255 veya 2:255",14,secondary());p.addView(info);EditText e=themedEdit("Sure ve ayet numarası");p.addView(e);Button b=btn("🔎 Bul");p.addView(b);LinearLayout result=new LinearLayout(this);result.setOrientation(LinearLayout.VERTICAL);p.addView(result);b.setOnClickListener(v->{int[] ref=parseRef(e.getText().toString());if(ref==null){Toast.makeText(this,"Örnek: Bakara 255 veya 2:255",Toast.LENGTH_SHORT).show();return;}fetchAyah(ref[0],ref[1],result);});setPage(p,"finder");}
    int[] parseRef(String s){s=s.trim();try{String[] parts=s.split(":");if(parts.length==2)return new int[]{Integer.parseInt(parts[0]),Integer.parseInt(parts[1])};String[] a=s.split("\\s+");if(a.length>=2){int ay=Integer.parseInt(a[a.length-1]);String name=s.substring(0,s.lastIndexOf(' ')).toLowerCase(new Locale("tr","TR"));String[] names={"fatiha","bakara","ali imran","nisa","maide","enam","araf","enfal","tevbe","yunus","hud","yusuf","rad","ibrahim","hicr","nahl","isra","kehf","meryem","taha","enbiya","hac","muminun","nur","furkan","şuara","neml","kasas","ankebut","rum","lokman","secde","ahzab","sebe","fatir","yasin","saffat","sad","zümer","mümin","fussilet","şura","zuhruf","duhan","casiye","ahkaf","muhammed","fetih","hucurat","kaf","zariyat","tur","necm","kamer","rahman","vakıa","hadid","mücadele","haşr","mümtehine","saff","cuma","münafikun","tegabun","talak","tahrim","mülk","kalem","hakka","mearic","nuh","cin","müzzemmil","müddessir","kıyamet","insan","mürselat","nebe","naziat","abese","tekvir","infitar","mutaffifin","inşikak","buruc","tarık","ala","gaşiye","fecr","beled","şems","leyl","duha","şerh","tin","alak","kadr","beyyine","zilzal","adiyat","karia","tekasür","asr","hümeze","fil","kureyş","maun","kevser","kafirun","nasr","tebbet","ihlas","felak","nas"};for(int i=0;i<names.length;i++)if(names[i].equals(name))return new int[]{i+1,ay};}}catch(Exception ignored){}return null;}

    void fetchAyah(int surah,int ayah,LinearLayout result){
        result.removeAllViews(); result.addView(tv("Yükleniyor...",16,secondary()));
        executor.execute(()->{
            try{
                String edition=findTurkishEdition();
                String url="https://api.alquran.cloud/v1/ayah/"+surah+":"+ayah+"/editions/quran-uthmani"+(edition.isEmpty()?"":","+edition);
                String a=get(url);
                JSONArray arr=new JSONObject(a).getJSONArray("data");
                JSONObject ar=arr.getJSONObject(0);
                JSONObject tr=arr.length()>1?arr.getJSONObject(1):null;
                String arabic=ar.optString("text","");
                String meal=tr==null?"Türkçe meal bulunamadı.":tr.optString("text","");
                int page=ar.optInt("page",1);
                String surahName=ar.optJSONObject("surah")!=null?ar.getJSONObject("surah").optString("englishName","Sure"):"Sure";
                runOnUiThread(()->{
                    result.removeAllViews();
                    result.addView(tv(surahName+" — "+ayah+". Ayet",19,primary()));
                    TextView aa=tv(arabic,26,text()); aa.setTextDirection(View.TEXT_DIRECTION_RTL); aa.setGravity(Gravity.RIGHT); result.addView(card(aa));
                    result.addView(card(tv("Türkçe meal\n"+meal,15,text())));
                    Button mush=btn("📖 Mushaf'ta Gör — Sayfa "+page); mush.setOnClickListener(v->showQuranReader(page)); result.addView(mush);
                });
            }catch(Exception e){
                runOnUiThread(()->{result.removeAllViews();result.addView(tv("Ayet alınamadı. İnternet bağlantınızı kontrol edin.",16,text()));});
            }
        });
    }

    String findTurkishEdition() throws Exception{
        String s=get("https://api.alquran.cloud/v1/edition?format=text&language=tr&type=translation");
        JSONArray a=new JSONObject(s).getJSONArray("data");
        for(int i=0;i<a.length();i++){String id=a.getJSONObject(i).optString("identifier","");if(!id.isEmpty())return id;}
        return "";
    }


    void showQuranReader(int page){
        lastQuranPage=Math.max(1,Math.min(604,page));
        prefs.edit().putInt(PREF_QURAN_PAGE,lastQuranPage).apply();

        LinearLayout p=page();
        base(p,"Kur'an'ı Oku");

        LinearLayout nav=new LinearLayout(this);
        Button prev=btn("◀");
        Button next=btn("▶");
        TextView pageNo=tv("Sayfa "+lastQuranPage+" / 604",17,primary());
        pageNo.setGravity(Gravity.CENTER);
        nav.addView(prev,new LinearLayout.LayoutParams(dp(55),dp(50)));
        nav.addView(pageNo,new LinearLayout.LayoutParams(0,dp(50),1));
        nav.addView(next,new LinearLayout.LayoutParams(dp(55),dp(50)));
        p.addView(nav);

        LinearLayout tools=new LinearLayout(this);
        tools.setGravity(Gravity.CENTER);
        Button go=btn("🔢 Sayfaya Git");
        Button mark=btn("🔖 Kaydet");
        tools.addView(go,new LinearLayout.LayoutParams(0,dp(50),1));
        tools.addView(mark,new LinearLayout.LayoutParams(0,dp(50),1));
        p.addView(tools);

        WebView w=new WebView(this);
        w.setBackgroundColor(night()?Color.rgb(16,25,31):Color.rgb(247,241,223));
        WebSettings ws=w.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setTextZoom(100);
        ws.setDefaultFontSize(18);
        ws.setDefaultFixedFontSize(18);
        ws.setDomStorageEnabled(true);

        w.setVerticalScrollBarEnabled(true);
        w.setHorizontalScrollBarEnabled(false);
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){
                super.onPageFinished(view,url);
                String bg=night()?"#10191f":"#f7f1df";
                String fg=night()?"#f5f8fa":"#2d2d2d";
                String js="(function(){try{"
                    +"var m=document.querySelector('meta[name=viewport]');"
                    +"if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
                    +"m.content='width=device-width,initial-scale=1,maximum-scale=5,user-scalable=yes';"
                    +"document.documentElement.style.background='"+bg+"';"
                    +"document.body.style.background='"+bg+"';"
                    +"document.body.style.color='"+fg+"';"
                    +"document.body.style.margin='0';"
                    +"document.body.style.padding='0';"
                    +"document.body.style.width='100%';"
                    +"document.body.style.overflowX='hidden';"
                    +"document.querySelectorAll('img,canvas,svg').forEach(function(x){x.style.maxWidth='100%';x.style.height='auto';});"
                    +"document.querySelectorAll('header,nav,footer').forEach(function(x){x.style.display='none';});"
                    +"var els=[...document.querySelectorAll('button,a')];"
                    +"var e=els.find(x=>x.textContent.trim()==='Single');if(e)e.click();"
                    +"}catch(e){}})();";
                view.evaluateJavascript(js,null);
            }
        });

        int h=getResources().getDisplayMetrics().heightPixels;
        int reserved=dp(145);
        p.addView(w,new LinearLayout.LayoutParams(-1,Math.max(dp(360),h-reserved)));

        String url="https://alquran.cloud/mushaf/"+lastQuranPage;
        w.loadUrl(url);

        prev.setOnClickListener(v->{if(lastQuranPage>1)showQuranReader(lastQuranPage-1);});
        next.setOnClickListener(v->{if(lastQuranPage<604)showQuranReader(lastQuranPage+1);});
        go.setOnClickListener(v->pageDialog());
        mark.setOnClickListener(v->{prefs.edit().putInt(PREF_QURAN_PAGE,lastQuranPage).apply();Toast.makeText(this,"Sayfa kaydedildi.",Toast.LENGTH_SHORT).show();});
        setPage(p,"quran");
    }

    void pageDialog(){final EditText e=themedEdit("1 - 604");e.setInputType(2);e.setHint("1 - 604");AlertDialog d=new AlertDialog.Builder(this).setTitle("Sayfaya Git").setView(e).setPositiveButton("Git",(dialog,w)->{try{int n=Integer.parseInt(e.getText().toString());if(n>=1&&n<=604)showQuranReader(n);else Toast.makeText(this,"1 ile 604 arasında bir sayı girin.",Toast.LENGTH_SHORT).show();}catch(Exception ex){}}).setNegativeButton("İptal",null).create();
        d.setOnShowListener(x->styleDialog(d)); d.show();}

    void showDualar(){LinearLayout p=page();base(p,"Dualar");String[] cats={"🛏️ Yatmadan Önce Okunacak Dualar","🍽️ Yemek Duaları","🤲 Şifa Duaları","🕋 Kur'an'daki Dualar","🕌 Peygamber Duaları"};for(String c:cats){Button b=btn(c);b.setOnClickListener(v->showDuaCategory(c));p.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));}setPage(p,"dualar");}
    void showDuaCategory(String cat){LinearLayout p=page();base(p,cat);String content=duaText(cat);TextView t=tv(content,16,text());t.setLineSpacing(0,1.15f);p.addView(card(t));Button share=btn("📤 Paylaş");share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,content+"\n\nNamaz Vaktim");startActivity(Intent.createChooser(i,"Dua paylaş"));});p.addView(share);setPage(p,"dua");}
    String duaText(String c){if(c.startsWith("🛏"))return "Yatarken Okunabilecek Dua\n\nاللَّهُمَّ أَسْلَمْتُ نَفْسِي إِلَيْكَ، وَوَجَّهْتُ وَجْهِيَ إِلَيْكَ...\n\nAnlamı: Allah'ım! Kendimi Sana teslim ettim ve yüzümü Sana çevirdim...\n\nKaynak: Buhârî, Deavât; Müslim, Zikir ve Dua.\n\nAyrıca Âyetü'l-Kürsî, İhlâs, Felak ve Nâs sureleri de okunabilir.";if(c.startsWith("🍽"))return "Yemek Öncesi\n\nبِسْمِ اللَّهِ\n\nOkunuş: Bismillâh.\nAnlamı: Allah'ın adıyla.\n\nYemek Sonrası\n\nالْحَمْدُ لِلَّهِ\n\nOkunuş: Elhamdülillâh.\nAnlamı: Hamd Allah'a mahsustur.\n\nNot: Uzun ve kaynağı belirsiz 'yemek duası' metinleri yerine kısa ve güvenilir zikirler tercih edilmiştir.";if(c.startsWith("🤲"))return "Şifa Duası\n\nاللَّهُمَّ رَبَّ النَّاسِ، أَذْهِبِ الْبَأْسَ، اشْفِ أَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ...\n\nAnlamı: Ey insanların Rabbi! Sıkıntıyı gider, şifa ver. Şifa veren Sensin; Senin şifandan başka şifa yoktur...\n\nKaynak: Buhârî, Merdâ; Müslim, Selâm.";if(c.startsWith("🕋"))return "Kur'an'daki Dualar\n\nرَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ\nBakara 2/201\n\nرَبِّ زِدْنِي عِلْمًا\nTâhâ 20/114\n\nرَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي\nTâhâ 20/25-26\n\nرَبَّنَا ظَلَمْنَا أَنْفُسَنَا\nA'râf 7/23\n\nلَا إِلَٰهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ\nEnbiyâ 21/87";return "Peygamber Duaları\n\nAllahümme Rabben-nâsi...\nHastalık ve şifa için rivayet edilen dua.\nKaynak: Buhârî, Merdâ; Müslim, Selâm.\n\nAllahümme innî es'elükel-hüdâ vet-tukâ vel-afâfe vel-gınâ.\nHidâyet, takvâ, iffet ve gönül zenginliği isteme duası.\nKaynak: Müslim, Zikir ve Dua.\n\nAllahümme innî es'elükel-cennete ve eûzü bike minen-nâr.\nCennet isteme ve ateşten korunma duası.\nKaynak: Ebû Dâvûd.";}

    void showSettings(){LinearLayout p=page();base(p,"Ayarlar");Button loc=btn("📍 Konum Değiştirme");loc.setOnClickListener(v->changeLocation());p.addView(loc);Button notif=btn("🔔 Bildirim Ayarı");notif.setOnClickListener(v->showNotificationSettings());p.addView(notif);Button theme=btn("🎨 Tema Ayarı");theme.setOnClickListener(v->showThemeDialog());p.addView(theme);TextView about=tv("Namaz Vaktim\nSürüm 1.4.0",13,secondary());about.setGravity(Gravity.CENTER);p.addView(about);setPage(p,"settings");}
    void changeLocation(){showFirstLaunch();prefs.edit().putBoolean(PREF_DONE,false).apply();}
    void showThemeDialog(){String[] o={"🟢 Yeşil Tema","🌙 Gece Teması"};AlertDialog d=new AlertDialog.Builder(this).setTitle("🎨 Tema Ayarı").setSingleChoiceItems(o,night()?1:0,(dialog,w)->{prefs.edit().putString(PREF_THEME,w==1?"night":"green").apply();dialog.dismiss();showMainScreen();}).create();
        d.setOnShowListener(x->styleDialog(d)); d.show();}
    void showNotificationSettings(){
        int current=prefs.getInt(PREF_NOTIFY_MIN,3);
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(8),dp(4),dp(8),0);
        CheckBox on=new CheckBox(this); on.setText("Namaz bildirimleri"); on.setChecked(prefs.getBoolean(PREF_NOTIFY_ON,true)); p.addView(on);
        CheckBox ay=new CheckBox(this); ay.setText("Günün Ayeti bildirimi"); ay.setChecked(prefs.getBoolean(PREF_AYET_NOTIFY,true)); p.addView(ay);
        TextView info=tv("Namaz vaktinden kaç dakika önce bildirim gelsin? 1–60 dakika arasında istediğiniz değeri yazabilirsiniz.",14,secondary()); p.addView(info);
        EditText min=new EditText(this); min.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); min.setSingleLine(true); min.setHint("Örn. 7"); min.setText(String.valueOf(current)); p.addView(min);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("🔔 Bildirim Ayarı").setView(p).setPositiveButton("Kaydet",(dialog,w)->{
            int value=current; try{value=Integer.parseInt(min.getText().toString().trim());}catch(Exception ignored){}
            value=Math.max(1,Math.min(60,value));
            prefs.edit().putBoolean(PREF_NOTIFY_ON,on.isChecked()).putBoolean(PREF_AYET_NOTIFY,ay.isChecked()).putInt(PREF_NOTIFY_MIN,value).apply();
            rescheduleNotifications();
        }).setNegativeButton("İptal",null).create();
        d.setOnShowListener(x->styleDialog(d)); d.show();
    }
    void rescheduleNotifications(){if(timings!=null)NotificationHelper.schedulePrayerNotifications(this,timings);NotificationHelper.scheduleDailyAyet(this);}

    void fillKerahetBox(LinearLayout b){b.removeAllViews();if(timings==null){b.addView(tv("Vakitler yüklendiğinde hesaplanır.",15,secondary()));return;}try{String sr=timings.optString("Sunrise").substring(0,5);String ss=timings.optString("Maghrib").substring(0,5);String dh=timings.optString("Dhuhr").substring(0,5);b.addView(tv("🌅 Güneş doğarken: "+sr+" — "+addMin(sr,20),16,text()));b.addView(tv("☀️ Öğle öncesi: "+subMin(dh,10)+" — "+dh,16,text()));b.addView(tv("🌇 Güneş batarken: "+subMin(ss,20)+" — "+ss,16,text()));}catch(Exception e){b.addView(tv("Kerahat vakitleri hesaplanamadı.",15,secondary()));}}
    String addMin(String s,int m){return shift(s,m);}String subMin(String s,int m){return shift(s,-m);}String shift(String s,int delta){try{String[] p=s.split(":");Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));c.set(Calendar.MINUTE,Integer.parseInt(p[1]));c.add(Calendar.MINUTE,delta);return String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));}catch(Exception e){return s;}}

    void requestLocation(boolean onboarding){boolean f=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;boolean c=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;if(!f&&!c){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},onboarding?21:20);return;}LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);try{boolean gps=lm.isProviderEnabled(LocationManager.GPS_PROVIDER);String provider=gps?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;Location l=lm.getLastKnownLocation(provider);if(l!=null){handleLocation(l.getLatitude(),l.getLongitude(),onboarding);return;}lm.requestSingleUpdate(provider,new LocationListener(){public void onLocationChanged(Location x){handleLocation(x.getLatitude(),x.getLongitude(),onboarding);}public void onProviderEnabled(String s){}public void onProviderDisabled(String s){}public void onStatusChanged(String s,int a,Bundle b){}},Looper.getMainLooper());Toast.makeText(this,"Konumunuz alınıyor...",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Konum alınamadı.",Toast.LENGTH_LONG).show();}}
    void handleLocation(double lat,double lon,boolean onboarding){
        executor.execute(()->{
            String city=resolveCity(lat,lon);
            if(city.isEmpty()) city="Konumum";
            final String selectedCity=city;
            runOnUiThread(()->{
                setQiblaBearing(lat,lon);
                prefs.edit().putString("city",selectedCity)
                    .putFloat("lat",(float)lat)
                    .putFloat("lon",(float)lon)
                    .putBoolean(PREF_DONE,true).apply();
                showMainScreen();
            });
        });
    }
    String resolveCity(double lat,double lon){try{Geocoder g=new Geocoder(this,new Locale("tr","TR"));List<Address>a=g.getFromLocation(lat,lon,1);if(a!=null&&!a.isEmpty()){String x=a.get(0).getLocality();if(x==null||x.isEmpty())x=a.get(0).getAdminArea();return x==null?"":x;}}catch(Exception ignored){}return "";}
    void useCityFromOnboarding(){
        String s=cityInput.getText().toString().trim();
        if(s.isEmpty()) return;
        executor.execute(()->{
            try{
                Geocoder g=new Geocoder(this,new Locale("tr","TR"));
                List<Address>a=g.getFromLocationName(s,1);
                if(a==null||a.isEmpty()){
                    runOnUiThread(()->Toast.makeText(this,"Şehir bulunamadı.",Toast.LENGTH_SHORT).show());
                    return;
                }
                Address x=a.get(0);
                String foundCity=x.getLocality();
                if(foundCity==null||foundCity.isEmpty()) foundCity=s;
                final String selectedCity=foundCity;
                double lat=x.getLatitude(),lon=x.getLongitude();
                runOnUiThread(()->{
                    prefs.edit().putString("city",selectedCity)
                        .putFloat("lat",(float)lat)
                        .putFloat("lon",(float)lon)
                        .putBoolean(PREF_DONE,true).apply();
                    showMainScreen();
                });
            }catch(Exception e){
                runOnUiThread(()->Toast.makeText(this,"Şehir aranırken hata oluştu.",Toast.LENGTH_LONG).show());
            }
        });
    }
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r==21&&g.length>0){boolean ok=false;for(int x:g)if(x==PackageManager.PERMISSION_GRANTED)ok=true;if(ok)requestLocation(true);}}

    void loadPrayer(double lat,double lon,String label){executor.execute(()->{try{String date=new SimpleDateFormat("dd-MM-yyyy",Locale.US).format(new Date());String s=get("https://api.aladhan.com/v1/timings/"+date+"?latitude="+lat+"&longitude="+lon+"&method=13");JSONObject t=new JSONObject(s).getJSONObject("data").getJSONObject("timings");timings=t;runOnUiThread(()->{if(locationText!=null)locationText.setText("Konum: "+label);if(prayerBox!=null){prayerBox.removeAllViews();String[] k={"Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"};String[] n={"Sabah","Güneş","Öğle","İkindi","Akşam","Yatsı"};for(int i=0;i<k.length;i++)prayerBox.addView(tv(n[i]+" — "+t.optString(k[i],"--:--"),18,text()));}if(currentScreen.equals("main")){rescheduleNotifications();} });}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Namaz vakitleri alınamadı. İnternet bağlantınızı kontrol edin.",Toast.LENGTH_LONG).show());}});}
    void updateCountdown(){if(countdownText==null||timings==null)return;try{String[] k={"Fajr","Dhuhr","Asr","Maghrib","Isha"};String[] n={"Sabah","Öğle","İkindi","Akşam","Yatsı"};Calendar now=Calendar.getInstance();Calendar target=null;String name="";for(int i=0;i<k.length;i++){String r=timings.optString(k[i],"");if(r.length()<5)continue;String[] z=r.substring(0,5).split(":");Calendar x=(Calendar)now.clone();x.set(Calendar.HOUR_OF_DAY,Integer.parseInt(z[0]));x.set(Calendar.MINUTE,Integer.parseInt(z[1]));x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);if(x.after(now)){target=x;name=n[i];break;}}if(target==null){String r=timings.optString("Fajr","");String[]z=r.substring(0,5).split(":");target=(Calendar)now.clone();target.add(Calendar.DAY_OF_YEAR,1);target.set(Calendar.HOUR_OF_DAY,Integer.parseInt(z[0]));target.set(Calendar.MINUTE,Integer.parseInt(z[1]));target.set(Calendar.SECOND,0);name="Sabah";}long d=target.getTimeInMillis()-now.getTimeInMillis();long h=d/3600000,m=(d%3600000)/60000,s=(d/1000)%60;countdownText.setText("⏳ "+name+" namazına "+h+" saat "+m+" dakika "+s+" saniye kaldı");}catch(Exception e){}}

    void showAyet(){try{JSONObject o=new JSONObject(new String(readAll(getAssets().open("365_ayet.json")),"UTF-8"));JSONArray a=o.getJSONArray("items");int d=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);if(d>365)d=365;JSONObject x=a.getJSONObject(d-1);categoryText.setText("Kategori: "+x.optString("category"));ayetArabic.setText(x.optString("arabic"));ayetTurkish.setText(x.optString("turkish_meaning"));ayetRef.setText(x.optString("surah")+" Suresi • "+x.optInt("ayah")+". Ayet");dateText.setText(new SimpleDateFormat("dd MMMM yyyy",new Locale("tr","TR")).format(new Date()));}catch(Exception e){}}
    void shareAyet(){
        shareAyetCard(ayetArabic==null?"":ayetArabic.getText().toString(),
                ayetTurkish==null?"":ayetTurkish.getText().toString(),
                ayetRef==null?"":ayetRef.getText().toString());
    }

    void shareAyetCard(String arabic,String turkish,String ref){
        try{
            int W=1080,H=1350;
            Bitmap bm=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);
            Canvas c=new Canvas(bm);
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            int bgc=night()?Color.rgb(10,31,26):Color.rgb(239,248,238);
            int panel=night()?Color.rgb(18,52,45):Color.rgb(255,255,250);
            int pc=night()?Color.rgb(119,226,137):Color.rgb(27,94,32);
            int tc=night()?Color.rgb(245,248,250):Color.rgb(40,50,42);
            c.drawColor(bgc);
            p.setColor(pc);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(54);
            c.drawText("Namaz Vaktim",70,95,p);

            p.setColor(panel);c.drawRoundRect(new RectF(55,145,1025,1210),36,36,p);

            p.setColor(tc);p.setTypeface(Typeface.DEFAULT);p.setTextSize(58);p.setTextAlign(Paint.Align.RIGHT);
            drawWrapped(c,arabic,p,970,245,900,78,Gravity.RIGHT);

            p.setTextAlign(Paint.Align.LEFT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(34);
            p.setColor(pc);c.drawText("Türkçe Meal",95,665,p);

            p.setTypeface(Typeface.DEFAULT);p.setTextSize(38);p.setColor(tc);
            drawWrapped(c,turkish,p,95,735,890,55,Gravity.LEFT);

            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(30);p.setColor(pc);
            drawWrapped(c,ref,p,95,1100,890,42,Gravity.LEFT);

            p.setTypeface(Typeface.DEFAULT);p.setTextSize(24);p.setColor(night()?Color.rgb(180,200,190):Color.rgb(100,120,105));
            c.drawText("Namaz Vaktim",70,1290,p);

            File dir=new File(getCacheDir(),"shared");if(!dir.exists())dir.mkdirs();
            File file=new File(dir,"ayet_"+System.currentTimeMillis()+".png");
            FileOutputStream fos=new FileOutputStream(file);bm.compress(Bitmap.CompressFormat.PNG,100,fos);fos.close();

            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",file);
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("ayet",uri));
            startActivity(Intent.createChooser(i,"Ayet görselini paylaş"));
        }catch(Exception e){
            Toast.makeText(this,"Ayet görseli oluşturulamadı.",Toast.LENGTH_LONG).show();
        }
    }

    void drawWrapped(Canvas c,String s,Paint p,float x,float y,float maxWidth,float lineHeight,int gravity){
        if(s==null)s="";
        String[] words=s.trim().split("\\s+"); String line=""; float yy=y;
        for(String word:words){
            String test=line.isEmpty()?word:line+" "+word;
            if(p.measureText(test)>maxWidth && !line.isEmpty()){
                if(gravity==Gravity.RIGHT)c.drawText(line,x,yy,p); else c.drawText(line,x,yy,p);
                yy+=lineHeight; line=word;
            }else line=test;
        }
        if(!line.isEmpty())c.drawText(line,x,yy,p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","NamazVaktim/1.4");InputStream is=c.getInputStream();return new String(readAll(is),"UTF-8");}
    static byte[] readAll(InputStream i)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[]x=new byte[8192];int n;while((n=i.read(x))!=-1)b.write(x,0,n);return b.toByteArray();}


    void setQiblaBearing(double lat,double lon){
        // Kaaba coordinates: 21.422487, 39.826206
        double lat1=Math.toRadians(lat), lat2=Math.toRadians(21.422487);
        double dLon=Math.toRadians(39.826206-lon);
        double y=Math.sin(dLon)*Math.cos(lat2);
        double x=Math.cos(lat1)*Math.sin(lat2)-Math.sin(lat1)*Math.cos(lat2)*Math.cos(dLon);
        qiblaBearing=(float)((Math.toDegrees(Math.atan2(y,x))+360)%360);
        if(qiblaView!=null)qiblaView.invalidate();
    }

    final SensorEventListener compassListener=new SensorEventListener(){
        @Override public void onSensorChanged(SensorEvent e){
            if(e.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
            float[] rotation=new float[9];float[] orientation=new float[3];
            SensorManager.getRotationMatrixFromVector(rotation,e.values);
            SensorManager.getOrientation(rotation,orientation);
            deviceAzimuth=(float)Math.toDegrees(orientation[0]);
            if(deviceAzimuth<0)deviceAzimuth+=360;
            if(qiblaView!=null)qiblaView.invalidate();
        }
        @Override public void onAccuracyChanged(Sensor s,int a){}
    };

    class QiblaCompassView extends View{
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        public QiblaCompassView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())*0.38f;
            paint.setStyle(Paint.Style.FILL);paint.setColor(surface());c.drawCircle(cx,cy,r+10,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setColor(primary());c.drawCircle(cx,cy,r,paint);
            paint.setStyle(Paint.Style.FILL);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(16);paint.setTextAlign(Paint.Align.CENTER);paint.setColor(text());
            c.drawText("N",cx,cy-r+20,paint);
            c.drawText("K",cx,cy+6,paint);
            float angle=(float)Math.toRadians(qiblaBearing-deviceAzimuth);
            float ax=cx+(float)Math.sin(angle)*r*0.78f;
            float ay=cy-(float)Math.cos(angle)*r*0.78f;
            paint.setColor(accent());paint.setStrokeWidth(7);paint.setStyle(Paint.Style.STROKE);
            c.drawLine(cx,cy,ax,ay,paint);
            paint.setStyle(Paint.Style.FILL);
            Path path=new Path();path.moveTo(ax,ay);path.lineTo(ax-12,ay+28);path.lineTo(ax+12,ay+28);path.close();c.drawPath(path,paint);
            paint.setColor(primary());c.drawCircle(cx,cy,8,paint);
        }
    }

    @Override public void onBackPressed(){if(currentScreen.equals("main")){super.onBackPressed();}else showMainScreen();}
    @Override protected void onResume(){
        super.onResume();
        if(sensorManager!=null && rotationSensor!=null){
            sensorManager.registerListener(compassListener,rotationSensor,SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override protected void onPause(){
        if(sensorManager!=null){
            sensorManager.unregisterListener(compassListener);
        }
        super.onPause();
    }

    @Override protected void onDestroy(){handler.removeCallbacks(ticker);executor.shutdownNow();super.onDestroy();}
}
