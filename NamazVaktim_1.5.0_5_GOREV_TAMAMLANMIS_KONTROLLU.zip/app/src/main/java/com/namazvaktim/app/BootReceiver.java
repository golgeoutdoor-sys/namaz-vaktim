package com.namazvaktim.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{
    @Override public void onReceive(Context c, Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            // Kullanıcı uygulamayı açtığında güncel vakitler yeniden planlanır.
        }
    }
}
