import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.initialize();
  runApp(const NamazVaktimApp());
}

class VerseRef {
  final int day;
  final String surah;
  final int surahNumber;
  final int ayah;
  final String category;
  final String arabic;
  final String turkishMeaning;
  VerseRef({required this.day, required this.surah, required this.surahNumber, required this.ayah, required this.category, required this.arabic, required this.turkishMeaning});

  factory VerseRef.fromJson(Map<String, dynamic> j) => VerseRef(
    day: j['day'] as int,
    surah: j['surah'] as String,
    surahNumber: j['surah_number'] as int,
    ayah: j['ayah'] as int,
    category: j['category'] as String,
    arabic: j['arabic'] as String,
    turkishMeaning: j['turkish_meaning'] as String,
  );
}

class VerseArchive {
  static List<VerseRef>? _items;

  static Future<List<VerseRef>> load() async {
    if (_items != null) return _items!;
    final raw = await rootBundle.loadString('assets/data/365_ayet.json');
    final decoded = jsonDecode(raw) as Map<String, dynamic>;
    final list = (decoded['items'] as List).cast<Map<String, dynamic>>();
    final items = list.map(VerseRef.fromJson).toList();
    if (items.length != 365) throw Exception('Ayet arşivi 365 kayıt içermeli.');
    final refs = <String>{};
    for (final item in items) {
      final key = '${item.surahNumber}|${item.ayah}';
      if (!refs.add(key)) throw Exception('Aynı ayet arşivde tekrar ediyor: $key');
    }
    _items = items;
    return _items!;
  }

  static Future<VerseRef> today() async {
    final items = await load();
    final start = DateTime(DateTime.now().year, 1, 1);
    final day = DateTime.now().difference(start).inDays + 1;
    return items[(day - 1) % items.length];
  }
}


class NamazVaktimApp extends StatelessWidget {
  const NamazVaktimApp({super.key});
  static const green = Color(0xFF173F35);
  static const cream = Color(0xFFF7F3EA);

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Namaz Vaktim',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(seedColor: green),
        ),
        home: const HomePage(),
      );
}

class PrayerTimes {
  final String location;
  final DateTime date;
  final Map<String, String> times;
  PrayerTimes({required this.location, required this.date, required this.times});

  Map<String, dynamic> toJson() => {
        'location': location,
        'date': date.toIso8601String(),
        'times': times,
      };

  factory PrayerTimes.fromJson(Map<String, dynamic> json) => PrayerTimes(
        location: json['location'] as String,
        date: DateTime.parse(json['date'] as String),
        times: Map<String, String>.from(json['times'] as Map),
      );
}

class PrayerService {
  // AlAdhan Method 13 = Diyanet İşleri Başkanlığı, Turkey.
  static const method = 13;

  Future<PrayerTimes> byCoordinates(double lat, double lon) async {
    final now = DateTime.now();
    final url = Uri.parse(
      'https://api.aladhan.com/v1/timings/${DateFormat('dd-MM-yyyy').format(now)}'
      '?latitude=$lat&longitude=$lon&method=$method',
    );
    final response = await http.get(url).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw Exception('Vakit servisine ulaşılamadı.');
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (body['code'] != 200) throw Exception('Vakit verisi alınamadı.');
    final data = body['data'] as Map<String, dynamic>;
    final timings = Map<String, dynamic>.from(data['timings']);
    final city = (data['meta']?['timezone'] ?? 'Konum').toString();
    return PrayerTimes(
      location: city.replaceAll('_', ' '),
      date: now,
      times: {
        'İmsak': _clean(timings['Fajr']),
        'Güneş': _clean(timings['Sunrise']),
        'Öğle': _clean(timings['Dhuhr']),
        'İkindi': _clean(timings['Asr']),
        'Akşam': _clean(timings['Maghrib']),
        'Yatsı': _clean(timings['Isha']),
      },
    );
  }

  Future<PrayerTimes> byCity(String city, String country) async {
    final now = DateTime.now();
    final url = Uri.parse(
      'https://api.aladhan.com/v1/timingsByCity/${DateFormat('dd-MM-yyyy').format(now)}'
      '?city=${Uri.encodeQueryComponent(city)}&country=${Uri.encodeQueryComponent(country)}&method=$method',
    );
    final response = await http.get(url).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw Exception('Vakit servisine ulaşılamadı.');
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    if (body['code'] != 200) throw Exception('Şehir için vakit bulunamadı.');
    final data = body['data'] as Map<String, dynamic>;
    final timings = Map<String, dynamic>.from(data['timings']);
    return PrayerTimes(
      location: '$city • Türkiye',
      date: now,
      times: {
        'İmsak': _clean(timings['Fajr']),
        'Güneş': _clean(timings['Sunrise']),
        'Öğle': _clean(timings['Dhuhr']),
        'İkindi': _clean(timings['Asr']),
        'Akşam': _clean(timings['Maghrib']),
        'Yatsı': _clean(timings['Isha']),
      },
    );
  }

  static String _clean(dynamic value) => value.toString().split(' ').first;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final service = PrayerService();
  PrayerTimes? prayerTimes;
  bool loading = true;
  String? error;
  Timer? ticker;
  Duration remaining = Duration.zero;

  @override
  void initState() {
    super.initState();
    loadSavedOrLocation();
    _scheduleVerseNotifications();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) => updateRemaining());
  }

  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  Future<void> _scheduleVerseNotifications() async {
    try {
      final raw = await rootBundle.loadString('assets/data/365_ayet.json');
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      final items = (decoded['items'] as List).cast<Map<String, dynamic>>();
      await NotificationService.instance.scheduleYearOfVerses(items);
    } catch (_) {}
  }

  Future<void> loadSavedOrLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString('prayer_cache');
    if (cached != null) {
      try {
        final p = PrayerTimes.fromJson(jsonDecode(cached));
        if (DateUtils.isSameDay(p.date, DateTime.now())) {
          setState(() {
            prayerTimes = p;
            loading = false;
          });
        }
      } catch (_) {}
    }
    await useCurrentLocation(silent: cached != null);
  }

  Future<void> useCurrentLocation({bool silent = false}) async {
    if (!silent) setState(() { loading = true; error = null; });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception('Konum servisi kapalı.');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        throw Exception('Konum izni verilmedi. Şehir seçerek devam edebilirsiniz.');
      }
      final pos = await Geolocator.getCurrentPosition();
      final result = await service.byCoordinates(pos.latitude, pos.longitude);
      await save(result);
      await NotificationService.instance.schedulePrayerNotifications(result.times);
      if (mounted) setState(() { prayerTimes = result; loading = false; error = null; });
    } catch (e) {
      if (mounted) setState(() { loading = false; error = e.toString().replaceFirst('Exception: ', ''); });
    }
  }

  Future<void> chooseCity() async {
    const cities = ['İstanbul','Ankara','İzmir','Bursa','Antalya','Adana','Konya','Gaziantep','Diyarbakır','Kayseri'];
    final city = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('Şehir Seç'),
        children: cities.map((c) => SimpleDialogOption(
          onPressed: () => Navigator.pop(dialogContext, c),
          child: Text(c),
        )).toList(),
      ),
    );
    if (city != null) await loadCity(city);
  }

  Future<void> loadCity(String city) async {
    setState(() { loading = true; error = null; });
    try {
      final result = await service.byCity(city, 'Turkey');
      await save(result);
      await NotificationService.instance.schedulePrayerNotifications(result.times);
      if (mounted) setState(() { prayerTimes = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { loading = false; error = e.toString().replaceFirst('Exception: ', ''); });
    }
  }

  Future<void> save(PrayerTimes p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('prayer_cache', jsonEncode(p.toJson()));
  }

  void updateRemaining() {
    final p = prayerTimes;
    if (p == null || !mounted) return;
    final now = DateTime.now();
    DateTime? target;
    String? name;
    for (final entry in p.times.entries) {
      final parts = entry.value.split(':');
      final t = DateTime(now.year, now.month, now.day, int.parse(parts[0]), int.parse(parts[1]));
      if (t.isAfter(now)) { target = t; name = entry.key; break; }
    }
    if (target == null) {
      final parts = p.times['İmsak']!.split(':');
      target = DateTime(now.year, now.month, now.day + 1, int.parse(parts[0]), int.parse(parts[1]));
      name = 'İmsak';
    }
    setState(() { remaining = target!.difference(now); });
  }

  @override
  Widget build(BuildContext context) {
    final p = prayerTimes;
    final next = p == null ? null : _nextPrayer(p);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: NamazVaktimApp.green,
        foregroundColor: Colors.white,
        title: const Text('NAMAZ VAKTİM', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())), icon: const Icon(Icons.settings_outlined))],
      ),
      body: RefreshIndicator(
        onRefresh: () => useCurrentLocation(),
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 28), children: [
          LocationCard(location: p?.location ?? 'Konum belirleniyor…', onChange: chooseCity, onGps: useCurrentLocation),
          const SizedBox(height: 18),
          if (loading) const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()))
          else if (error != null) ErrorCard(message: error!, onRetry: useCurrentLocation, onCity: chooseCity)
          else if (p != null) ...[
            Text('Sıradaki Vakit', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: NamazVaktimApp.green)),
            const SizedBox(height: 8),
            Container(
              width: double.infinity, padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(color: NamazVaktimApp.green, borderRadius: BorderRadius.circular(26)),
              child: Column(children: [
                Text(next?.$1.toUpperCase() ?? '', style: const TextStyle(color: Colors.white70, letterSpacing: 2, fontWeight: FontWeight.w700)),
                const SizedBox(height: 5), Text(next?.$2 ?? '--:--', style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6), Text('Kalan ${_formatDuration(remaining)}', style: const TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 18),
            PrayerTimesCard(times: p.times),
            const SizedBox(height: 18), const VerseCard(),
          ],
        ]),
      ),
      bottomNavigationBar: const NavigationBar(selectedIndex: 0, destinations: [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Ayetler'),
        NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Bildirimler'),
      ]),
    );
  }

  (String, String)? _nextPrayer(PrayerTimes p) {
    final now = DateTime.now();
    for (final e in p.times.entries) {
      final a = e.value.split(':');
      final t = DateTime(now.year, now.month, now.day, int.parse(a[0]), int.parse(a[1]));
      if (t.isAfter(now)) return (e.key, e.value);
    }
    return ('İmsak', p.times['İmsak']!);
  }

  String _formatDuration(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }
}

class LocationCard extends StatelessWidget {
  final String location; final VoidCallback onChange; final VoidCallback onGps;
  const LocationCard({super.key, required this.location, required this.onChange, required this.onGps});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [
      const Icon(Icons.location_on_outlined, color: NamazVaktimApp.green), const SizedBox(width: 10),
      Expanded(child: Text(location, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
      IconButton(tooltip: 'GPS ile yenile', onPressed: onGps, icon: const Icon(Icons.my_location)),
      TextButton(onPressed: onChange, child: const Text('Değiştir')),
    ]),
  );
}

class ErrorCard extends StatelessWidget {
  final String message; final VoidCallback onRetry, onCity;
  const ErrorCard({super.key, required this.message, required this.onRetry, required this.onCity});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
    const Icon(Icons.info_outline, size: 38, color: NamazVaktimApp.green), const SizedBox(height: 10), Text(message, textAlign: TextAlign.center),
    const SizedBox(height: 12), Wrap(spacing: 8, children: [OutlinedButton(onPressed: onCity, child: const Text('Şehir Seç')), FilledButton(onPressed: onRetry, child: const Text('Tekrar Dene'))]),
  ])));
}

class PrayerTimesCard extends StatelessWidget {
  final Map<String, String> times;
  const PrayerTimesCard({super.key, required this.times});
  static const icons = {'İmsak': Icons.nightlight_outlined, 'Güneş': Icons.wb_sunny_outlined, 'Öğle': Icons.wb_sunny, 'İkindi': Icons.wb_twilight, 'Akşam': Icons.nights_stay_outlined, 'Yatsı': Icons.bedtime_outlined};
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Bugünün Namaz Vakitleri', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 10),
    ...times.entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Icon(icons[e.key], size: 21, color: NamazVaktimApp.green), const SizedBox(width: 12), Expanded(child: Text(e.key, style: const TextStyle(fontWeight: FontWeight.w600))), Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800))]))),
  ]));
}

class VerseCard extends StatelessWidget {
  const VerseCard({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<VerseRef>(
    future: VerseArchive.today(),
    builder: (context, snap) {
      if (!snap.hasData) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Günün ayeti hazırlanıyor…')));
      final v = snap.data!;
      final reference = '${v.surah} Suresi, ${v.ayah}. Ayet';
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFFE6EEE8), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [Icon(Icons.menu_book_outlined, color: NamazVaktimApp.green), SizedBox(width: 8), Text('Günün Ayeti', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: NamazVaktimApp.green))]),
          const SizedBox(height: 14),
          Text('Gün ${v.day} • ${v.category}', style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text(v.arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 22, height: 1.8, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          Text(v.turkishMeaning, style: const TextStyle(fontSize: 17, height: 1.5, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Text(reference, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => SharePlus.instance.share(ShareParams(text: '${v.turkishMeaning}\n\n$reference\n\nNamaz Vaktim')),
            icon: const Icon(Icons.share_outlined), label: const Text('Ayet Paylaş')),
        ]),
      );
    },
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Ayarlar')), body: ListView(padding: const EdgeInsets.all(18), children: [
    const ListTile(leading: Icon(Icons.notifications_outlined), title: Text('Namaz bildirimleri'), subtitle: Text('Varsayılan: 3 dakika önce')),
    const Divider(),
    const ListTile(leading: Icon(Icons.schedule), title: Text('Bildirim zamanı'), subtitle: Text('3 dakika önce')),
    const ListTile(leading: Icon(Icons.menu_book_outlined), title: Text('Günün ayeti bildirimleri'), subtitle: Text('Açık')), 
    const Divider(),
    const ListTile(leading: Icon(Icons.info_outline), title: Text('Lisanslar'), subtitle: Text('365 ayet • Elmalılı meal • Kaynak ve lisans bilgileri')),
  ]));
}
