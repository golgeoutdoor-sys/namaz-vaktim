import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();
  final FlutterLocalNotificationsPlugin plugin = FlutterLocalNotificationsPlugin();

  static const AndroidNotificationChannel prayerChannel = AndroidNotificationChannel(
    'prayer_times',
    'Namaz Vakitleri',
    description: 'Namaz vaktinden 3 dakika önce bildirimler.',
    importance: Importance.high,
  );

  static const AndroidNotificationChannel verseChannel = AndroidNotificationChannel(
    'daily_verse',
    'Günün Ayeti',
    description: 'Her gün günün ayeti bildirimi.',
    importance: Importance.defaultImportance,
  );

  Future<void> initialize() async {
    tz.initializeTimeZones();
    final timeZoneInfo = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timeZoneInfo.identifier));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);

    final androidPlugin = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(prayerChannel);
    await androidPlugin?.createNotificationChannel(verseChannel);
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  Future<void> schedulePrayerNotifications(Map<String, String> times) async {
    final now = DateTime.now();
    // Bu sürümün bildirimlerini temizleyip bugünün vakitlerini yeniden kuruyoruz.
    for (int id = 100; id < 106; id++) {
      await plugin.cancel(id);
    }

    int id = 100;
    for (final entry in times.entries) {
      final parts = entry.value.split(':');
      if (parts.length < 2) continue;
      final prayer = DateTime(now.year, now.month, now.day,
          int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0);
      final notificationTime = prayer.subtract(const Duration(minutes: 3));
      if (!notificationTime.isAfter(now)) {
        id++;
        continue;
      }

      await plugin.zonedSchedule(
        id,
        'Namaz Vaktim',
        '${entry.key} vaktine 3 dakika kaldı.',
        tz.TZDateTime.from(notificationTime, tz.local),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_times',
            'Namaz Vakitleri',
            channelDescription: 'Namaz vaktinden 3 dakika önce bildirimler.',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      );
      id++;
    }
  }

  Future<void> scheduleYearOfVerses(List<Map<String, dynamic>> verses) async {
    // Günün ayeti için 365 günlük bildirimleri yıl boyunca tek seferde kuruyoruz.
    // Aynı ID aralığını temizleyerek güncellemeyi güvenli hale getiriyoruz.
    for (int id = 1000; id < 1365; id++) {
      await plugin.cancel(id);
    }

    final year = DateTime.now().year;
    for (final item in verses) {
      final day = item['day'] as int;
      final date = DateTime(year, 1, day, 9, 0);
      final scheduled = tz.TZDateTime.from(date, tz.local);
      if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) continue;

      final title = 'Namaz Vaktim • Günün Ayeti';
      final body = '${item['turkish_meaning']} — ${item['surah']} ${item['ayah']}';
      await plugin.zonedSchedule(
        1000 + day - 1,
        title,
        body,
        scheduled,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'daily_verse',
            'Günün Ayeti',
            channelDescription: 'Her gün günün ayeti bildirimi.',
            importance: Importance.defaultImportance,
            priority: Priority.defaultPriority,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      );
    }
  }
}
