# Namaz Vaktim 1.0

Android için namaz vakitleri ve günlük ayet uygulaması.

## Özellikler
- Konuma göre namaz vakitleri
- Manuel şehir/konum seçimi
- Namaz vaktinden 3 dakika önce bildirim
- 365 günlük offline Günün Ayeti arşivi
- Her gün tek ve benzersiz ayet
- Arapça + Elmalılı Türkçe meal
- Ayet paylaşımı
- Ayarlar ve lisans bölümü
- Android bildirim izinleri ve hassas alarm desteği

## Test
Flutter kurulu bir bilgisayarda:
```bash
flutter pub get
flutter run
```

Test APK:
```bash
flutter build apk --release
```

Google Play:
```bash
flutter build appbundle --release
```

Not: Bu paket kaynak projedir; bu çalışma ortamında Android SDK/Flutter olmadığı için APK burada derlenmemiştir.
