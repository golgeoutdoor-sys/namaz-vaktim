# Namaz Vaktim 1.5.0

Bu sürüm, onaylanan geliştirmelerin doğrudan Android proje kaynaklarına uygulanmış halidir.

## Uygulanan geliştirmeler

1. **Kıble pusulası:** konumdan Kâbe yönü hesaplanır; dönüş sensörü veya ivmeölçer + manyetik sensör ile telefon hareketine göre ok güncellenir.
2. **Kur'an okuyucu:** 604 sayfa, sayfa ileri/geri, sayfaya gitme, son sayfayı kaydetme, yakınlaştırma ve genişliğe uyarlama bulunur; WebView tema renklerini takip eder.
3. **Tema sistemi:** yeşil ve gece teması sayfalara, kartlara, butonlara, giriş alanlarına ve checkbox'lara uygulanır.
4. **Sabah namazı:** Fajr kullanıcı arayüzünde Sabah olarak gösterilir; geri sayım Sabah namazına şeklindedir.
5. **Ayet paylaşımı:** Arapça ayet + Türkçe meal + sure/ayet + kategori içeren PNG oluşturulur ve Android paylaşım menüsüne gönderilir.
6. **FileProvider:** PNG paylaşımı için FileProvider ve cache path tanımlıdır.

## Derleme

GitHub Actions workflow, Java 17 + Gradle 8.9 ile `app:assembleDebug` çalıştırır ve APK'yı `NamazVaktim-1.5.0-debug-apk` artifact olarak yükler. Ayrıca altı ana geliştirmenin kaynak kodda bulunduğunu derleme öncesi kontrol eder.
