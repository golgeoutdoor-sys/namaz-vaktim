package com.namazvaktim.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                android.content.SharedPreferences prefs =
                        context.getSharedPreferences("namaz", Context.MODE_PRIVATE);
                double lat = prefs.getFloat("lat", 0f);
                double lon = prefs.getFloat("lon", 0f);
                if (lat == 0 && lon == 0) return;

                String date = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
                String url = "https://api.aladhan.com/v1/timings/" + date
                        + "?latitude=" + lat + "&longitude=" + lon + "&method=13";
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setRequestProperty("User-Agent", "NamazVaktim/1.5");
                InputStream is = c.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
                is.close();
                JSONObject timings = new JSONObject(new String(out.toByteArray(), "UTF-8"))
                        .getJSONObject("data").getJSONObject("timings");

                NotificationHelper.createChannels(context);
                NotificationHelper.schedulePrayerNotifications(context, timings);
                NotificationHelper.scheduleDailyAyet(context);
            } catch (Exception ignored) {
                // Boot should never crash the app because of a temporary network failure.
            } finally {
                pending.finish();
            }
        }).start();
    }
}
